(function(){
	'use strict';
	angular
		.module('clashApp', ['ngResource', 'ngRoute']);
})();